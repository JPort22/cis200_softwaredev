﻿//Grading ID: M1402
//Due Date: 12/3/2019
//Program 5 EC : to sort object in an in-order traversal while testing a generic tree class
//CIS 200-01

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_5_EC
{
    class Program
    {
        //Precondition: None
        //Postcondition: test binary tree with assortment of objects to compile tree
        static void Main(string[] args)
        {
            int[] intArray = { 8, 2, 4, 3, 1, 7, 5, 6, 10, 9 };//list of int objects
            double[] doubleArray = { 8.8, 2.2, 4.4, 3.3, 1.1, 7.7, 5.5, 6.6, 10.1, 9.9 };//list of double objects
            string[] stringArray =
               {"Naruto", "Kakashi", "Baymax","Spongebob", "Pearl", "Larry", "Natsu", "Erza", "Jin", "Mugen"};//list of string objects

            // create int Tree
            Tree<int> intTree = new Tree<int>();
            PopulateTree(intArray, intTree, nameof(intTree));
            TraverseTree(intTree, nameof(intTree));
            Pause();

            // create double Tree
            Tree<double> doubleTree = new Tree<double>();
            PopulateTree(doubleArray, doubleTree, nameof(doubleTree));
            TraverseTree(doubleTree, nameof(doubleTree));
            Pause();

            // create string Tree
            Tree<string> stringTree = new Tree<string>();
            PopulateTree(stringArray, stringTree, nameof(stringTree));
            TraverseTree(stringTree, nameof(stringTree));
            
        }//code was extracted from figure 19.24 from the Visual C# text

        // populate Tree with array elements
        //Precondition: has parameters that needs to be met
        //Postcondition: populates binary tree with objects instantiated 
        private static void PopulateTree<T>(Array array, Tree<T> tree, string name) where T : IComparable<T>
        {
            Console.WriteLine($"\n\n\nInserting into {name}:");

            foreach (IComparable data in array)
            {
                Console.Write($"{data} ");
                tree.InsertNode(data);
            }
        }

        // perform traversals
        //Precondition: has parameters that need to be met
        //Postcondition: performs the desired traversals for output
        private static void TraverseTree<T>(Tree<T> tree, string treeType) where T : IComparable<T>
        {
            // perform inorder traversal of tree
            Console.WriteLine($"\n\nInorder traversal of {treeType}");
            tree.InorderTraversal();
            Console.WriteLine();
        }

        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            Console.WriteLine("Press Enter to Continue...");
            Console.ReadLine();

            Console.Clear(); // Clear screen
        }
    }
   
}
