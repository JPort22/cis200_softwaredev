﻿//Grading ID: M1402
//CIS 200-01
//Program 5-EC: sorting objects in an inorder traversal, testing ability of generic tree class
//Due Date: 12/3/2019

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_5_EC
{
    class TreeNode<T> where T : IComparable<T>
    {
        // automatic property LeftNode
        public TreeNode<T> LeftNode 
        //Precondition: None
        //Postcondition: left node returned
        { get; 
            
         //Precondition: None
         //Postcondition: left node is set to desired values
        set; }

        // automatic property Data
        public IComparable Data 
        //Precondition: None
        //Postcondition: data is returned
        { get; 
        //Precondition: None
        //Postcondition: data is set and can't be changed
        private set; }

        // automatic property RightNode
        public TreeNode<T> RightNode 
        //Precondition: None
        //Postcondition: right node is returned
        { get; 
         //Precondition: None
         //Postcondition: right node is set to desired values
        set; }

        // initialize Data and make this a leaf node
        //Precondition: Data is initialized 
        //Postcondition: makes data icomparable and a leaf node for sorting order
        public TreeNode(IComparable nodeData)
        {
            Data = nodeData;
        }

        // insert TreeNode into Tree that contains nodes;
        // ignore duplicate values
        //Precondition: needs icomparable insert value
        //Postcondition: inserts TreeNodes into the Tree with values
        public void Insert(IComparable insertValue)
        {
            if (insertValue.CompareTo(Data) < 0) // insert in left subtree
            {
                // insert new TreeNode
                if (LeftNode == null)
                {
                    LeftNode = new TreeNode<T>(insertValue);
                }
                else // continue traversing left subtree
                {
                    LeftNode.Insert(insertValue);
                }
            }
            else if (insertValue.CompareTo(Data) > 0) // insert in right
            {
                // insert new TreeNode
                if (RightNode == null)
                {
                    RightNode = new TreeNode<T>(insertValue);
                }
                else // continue traversing right subtree
                {
                    RightNode.Insert(insertValue);
                }
            }
        }//code was extracted from figure 19.23 from Visual C# text
    }

    // class Tree declaration
    //Precondition: takes values from Insert value to build tree with icomparable values
    //Postcondition: class Tree is declared and root is established
    public class Tree<T> where T : IComparable<T>
    {
        private TreeNode<T> root;

        // Insert a new node in the binary search tree.
        // If the root node is null, create the root node here.
        // Otherwise, call the insert method of class TreeNode.
        public void InsertNode(IComparable insertValue)
        {
            if (root == null)
            {
                root = new TreeNode<T>(insertValue);
            }
            else
            {
                root.Insert(insertValue);
            }
        }

        // begin preorder traversal
        //Precondition: None
        //Postcondition: starts to build the preorder traversal
        public void PreorderTraversal()
        {
            PreorderHelper(root);
        }

        // recursive method to perform preorder traversal
        //Precondition:none
        //Postcondition: method is recursive and performs the preorder traversal for output
        private void PreorderHelper(TreeNode<T> node)
        {
            if (node != null)
            {
                // output node Data
                Console.Write($"{node.Data} ");

                // traverse left subtree
                PreorderHelper(node.LeftNode);

                // traverse right subtree
                PreorderHelper(node.RightNode);
            }
        }

        // begin inorder traversal
        //Precondition: None
        //Postcondition: begins to build the inorder traversal
        public void InorderTraversal()
        {
            InorderHelper(root);
        }

        // recursive method to perform inorder traversal
        //Precondition: none
        //Postcondition: inorder method is recursive and starts to perform the inorder traversal for output
        private void InorderHelper(TreeNode<T> node)
        {
            if (node != null)
            {
                // traverse left subtree
                InorderHelper(node.LeftNode);

                // output node data
                Console.Write($"{node.Data} ");

                // traverse right subtree
                InorderHelper(node.RightNode);
            }
        }

        // begin postorder traversal
        //Precondition: none
        //Postcondition: begins to build postorder traversal
        public void PostorderTraversal()
        {
            PostorderHelper(root);
        }

        // recursive method to perform postorder traversal
        //Precondition: None
        //Postcondition: postorder method is recursive and begins forming tree
        private void PostorderHelper(TreeNode<T> node)
        {
            if (node != null)
            {
                // traverse left subtree
                PostorderHelper(node.LeftNode);

                // traverse right subtree
                PostorderHelper(node.RightNode);

                // output node Data
                Console.Write($"{node.Data} ");
            }
        }
    }
}
