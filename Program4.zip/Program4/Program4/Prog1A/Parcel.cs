﻿// Program 0
// CIS 200-01
// Fall 201
// Due: 9/9/2019
// By: Andrew L. Wright (students use Grading ID)

// File: Parcel.cs
// Parcel serves as the abstract base class of the Parcel hierachy.
//Grading ID: M1402
//Program 4- adding sorts to the the output
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public abstract class Parcel : IComparable<Parcel>
{
    // Precondition:  None
    // Postcondition: The parcel is created with the specified values for
    //                origin address and destination address
    public Parcel(Address originAddress, Address destAddress)
    {
        OriginAddress = originAddress;
        DestinationAddress = destAddress;
    }

    public Address OriginAddress
    {
        // Precondition:  None
        // Postcondition: The parcel's origin address has been returned
        get;

        // Precondition:  None
        // Postcondition: The parcel's origin address has been set to the
        //                specified value
        set;
    }

    public Address DestinationAddress
    {
        // Precondition:  None
        // Postcondition: The parcel's destination address has been returned
        get;

        // Precondition:  None
        // Postcondition: The parcel's destination address has been set to the
        //                specified value
        set;
    }

    // Precondition:  None
    // Postcondition: The parcel's cost has been returned
    public abstract decimal CalcCost();

    // Precondition:  None
    // Postcondition: A String with the parcel's data has been returned
    public override String ToString()
    {
        string NL = Environment.NewLine; // NewLine shortcut

        return $"Origin Address:{NL}{OriginAddress}{NL}{NL}Destination Address:{NL}" +
            $"{DestinationAddress}{NL}Cost: {CalcCost():C}";
    }
    //Precondition: None
    //Postcondition:Compares parcels and then fixed cost

    public int CompareTo(Parcel p1)
    {
        //if both are null
        if (this == null && p1 == null)
            return 0;//equal

        //if only class Parcel is null
        if (this == null)
            return -1;//less than any 
        //only p1 is null
        if (p1 == null)
            return 1;//more than any, returns positive #

        //comparing costs between parcels
        if (this.CalcCost() < p1.CalcCost())
            return -1;//returns negative #
        //comparing costs between parcels
        if (this.CalcCost() == p1.CalcCost())
            return 0;//returns 0
        //if other conditions aren't met
        else
            return 1;//returns positive #
    }
}
