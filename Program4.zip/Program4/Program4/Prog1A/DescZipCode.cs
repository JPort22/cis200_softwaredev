﻿//Grading ID: M1402
//CIS 200-01
//Program 4- descending order for zip code
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class DescZipCode : Comparer<Parcel>
    {
        //Precondition: None
        //Postcondition: Descending, opposite of natural sort, for zip code, 
                //sorted in descending order when p1 < p2, method returns positive #
                //when p1 == p2, method returns zero
                //when p1 > p2, method returns a negative #

        public override int Compare(Parcel p1, Parcel p2)
        {
            
            if (p1 == null && p2 == null)//both are null
                return 0;//equal
            
            if (p1 == null)//only p1 is null
                return -1;//null is less than any actual zipcode

            if (p2 == null)//only t2 is null
                return 1;//zipcode is greater than null

            return -1 * p1.DestinationAddress.Zip.CompareTo(p2.DestinationAddress.Zip); //multiply by -1 for descending zip order
        }

    }
}
