﻿// Program 1A
// CIS 200-01
// Fall 2019
// Due: 9/23/2019
// By: Andrew L. Wright (students use Grading ID)

// File: TestParcels.cs
// This is a simple, console application designed to exercise the Parcel hierarchy.
// It creates several different Parcels and prints them.

//Grading ID: M1402
//CIS 200-01
//Program 4
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace Prog1
{
    class TestParcels
    {
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            // Test Data - Magic Numbers OK
            Address a1 = new Address("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
                "  Louisville   ", "  KY   ", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("Mermaid Man", "1960 Coral Ave", "Bikini Bottom", "PC", 45997);//Test address 5
            Address a6 = new Address("Polar Bear", "215 Iceberg", "Anchorage", "AK", 67544);//Test address 6
            Address a7 = new Address("Thor Odinson", "278 Golden Palace", "Apt. 54", "AG", 11177);//test address 7
            Address a8 = new Address("Izuku Midoriya", "339 Quirk Place", "Musutafu", "JP", 66445);//test address 8


            Letter letter1 = new Letter(a1, a2, 3.95M);                            // Letter test object
            Letter letter2 = new Letter(a6, a4, 7.32M); //Letter test object
            Letter letter3 = new Letter(a5, a8, 2.76M);//Letter test object
            GroundPackage gp1 = new GroundPackage(a3, a4, 14, 10, 5, 12.5);        // Ground test object
            GroundPackage gp2 = new GroundPackage(a7, a5, 18, 23, 11, 22.9);    //Ground test object
            GroundPackage gp3 = new GroundPackage(a2, a6, 23, 34, 17, 78.3);//Ground test object
            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 25, 15, 15,    // Next Day test object
                85, 7.50M);
            NextDayAirPackage ndap2 = new NextDayAirPackage(a4, a7, 4, 10, 6, 26, 3.43M); // next day air package test object
            NextDayAirPackage ndap3 = new NextDayAirPackage(a3, a8, 37, 44, 22, 56, 5.76M); //next day air package test object
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a4, a1, 46.5, 39.5, 28.0, // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a2, a5, 28, 45, 17, 23, TwoDayAirPackage.Delivery.Early); //two day test object
            TwoDayAirPackage tdap3 = new TwoDayAirPackage(a1, a6, 7, 13, 8, 13, TwoDayAirPackage.Delivery.Saver); //two day test object

            List<Parcel> parcels;      // List of test parcels

            parcels = new List<Parcel>();

            parcels.Add(letter1); // Populate list
            parcels.Add(letter2);
            parcels.Add(letter3);
            parcels.Add(gp1);
            parcels.Add(gp2);
            parcels.Add(gp3);
            parcels.Add(ndap1);
            parcels.Add(ndap2);
            parcels.Add(ndap3);
            parcels.Add(tdap1);
            parcels.Add(tdap2);
            parcels.Add(tdap3);


            WriteLine("Original List:");
            WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                WriteLine(p);
                WriteLine("====================");
            }
            Pause();
            //comment
            parcels.Sort();

            WriteLine("Sorted List:");
            WriteLine("=======================");
            foreach (Parcel p in parcels)
            {
                WriteLine(p);
                WriteLine("=========================");
            }
            Pause();
            //comment
            parcels.Sort(new DescZipCode());

            WriteLine("Descending Zip Code Sorted List: ");
            WriteLine("============================");
            foreach (Parcel p in parcels)
            {
                WriteLine(p);
                WriteLine("========================");
            }
            Pause();
            //comment
            parcels.Sort(new AscTypeDescCostSort());

            WriteLine("Ascending Type and Cost Descending: ");
            WriteLine("============================");
            foreach (Parcel p in parcels)
            {
                WriteLine(p);
                WriteLine("=========================");
            }
            Pause();
        }

        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            WriteLine("Press Enter to Continue...");
            ReadLine();

            Console.Clear(); // Clear screen
        }
    }
}
