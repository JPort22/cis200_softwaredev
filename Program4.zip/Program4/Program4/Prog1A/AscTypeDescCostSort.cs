﻿//Grading ID: M1402
//CIS 200-01
//Program 4-ascending parcel type and descending cost
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class AscTypeDescCostSort : Comparer<Parcel>
    {
        //Precondition: None
        //Postcondition: Ascending parcel type and descending cost sort
                //when p1 and p2 are null returns zero
                //when only p1 is null returns negative #
                //when only p2 is null returns positve #

        public override int Compare(Parcel p1, Parcel p2)
        {
            
            if (p1 == null && p2 == null)//both are null
                return 0;//returns zero

            if (p1 == null)//p1 is null only
                return -1;//returns negative #

            if (p2 == null)//only p2 is null only
                return 1;//returns positive #

            if (p1.GetType().ToString() == p2.GetType().ToString())
                return -1 * p1.CompareTo(p2);//compares parcel types for output, descending  cost

            else
                return p1.GetType().ToString().CompareTo(p2.GetType().ToString());//comparing p1 and p2 GetTypes and output to string
        }
    }
}
