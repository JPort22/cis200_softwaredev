﻿namespace UPVApp
{
    partial class AddressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddressForm));
            this.nameLbl = new System.Windows.Forms.Label();
            this.nameTxtBx = new System.Windows.Forms.TextBox();
            this.addressLbl = new System.Windows.Forms.Label();
            this.addTxt1Bx = new System.Windows.Forms.TextBox();
            this.cityLbl = new System.Windows.Forms.Label();
            this.Addtxt2Bx = new System.Windows.Forms.TextBox();
            this.CitytxtBx = new System.Windows.Forms.TextBox();
            this.zipLbl = new System.Windows.Forms.Label();
            this.stateLbl = new System.Windows.Forms.Label();
            this.zipCodetxtBx = new System.Windows.Forms.TextBox();
            this.stateComboBx = new System.Windows.Forms.ComboBox();
            this.submitBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.Location = new System.Drawing.Point(24, 26);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(79, 29);
            this.nameLbl.TabIndex = 0;
            this.nameLbl.Text = "Name:";
            // 
            // nameTxtBx
            // 
            this.nameTxtBx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameTxtBx.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameTxtBx.Location = new System.Drawing.Point(186, 26);
            this.nameTxtBx.Name = "nameTxtBx";
            this.nameTxtBx.Size = new System.Drawing.Size(378, 32);
            this.nameTxtBx.TabIndex = 1;
            // 
            // addressLbl
            // 
            this.addressLbl.AutoSize = true;
            this.addressLbl.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressLbl.Location = new System.Drawing.Point(12, 75);
            this.addressLbl.Name = "addressLbl";
            this.addressLbl.Size = new System.Drawing.Size(102, 29);
            this.addressLbl.TabIndex = 2;
            this.addressLbl.Text = "Address:";
            // 
            // addTxt1Bx
            // 
            this.addTxt1Bx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addTxt1Bx.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addTxt1Bx.Location = new System.Drawing.Point(186, 73);
            this.addTxt1Bx.Name = "addTxt1Bx";
            this.addTxt1Bx.Size = new System.Drawing.Size(378, 32);
            this.addTxt1Bx.TabIndex = 3;
            // 
            // cityLbl
            // 
            this.cityLbl.AutoSize = true;
            this.cityLbl.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cityLbl.Location = new System.Drawing.Point(24, 163);
            this.cityLbl.Name = "cityLbl";
            this.cityLbl.Size = new System.Drawing.Size(61, 29);
            this.cityLbl.TabIndex = 4;
            this.cityLbl.Text = "City:";
            // 
            // Addtxt2Bx
            // 
            this.Addtxt2Bx.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addtxt2Bx.Location = new System.Drawing.Point(186, 121);
            this.Addtxt2Bx.Name = "Addtxt2Bx";
            this.Addtxt2Bx.Size = new System.Drawing.Size(378, 32);
            this.Addtxt2Bx.TabIndex = 5;
            // 
            // CitytxtBx
            // 
            this.CitytxtBx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CitytxtBx.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CitytxtBx.Location = new System.Drawing.Point(186, 165);
            this.CitytxtBx.Name = "CitytxtBx";
            this.CitytxtBx.Size = new System.Drawing.Size(378, 32);
            this.CitytxtBx.TabIndex = 6;
            // 
            // zipLbl
            // 
            this.zipLbl.AutoSize = true;
            this.zipLbl.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zipLbl.Location = new System.Drawing.Point(24, 252);
            this.zipLbl.Name = "zipLbl";
            this.zipLbl.Size = new System.Drawing.Size(108, 29);
            this.zipLbl.TabIndex = 7;
            this.zipLbl.Text = "Zip Code:";
            // 
            // stateLbl
            // 
            this.stateLbl.AutoSize = true;
            this.stateLbl.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stateLbl.Location = new System.Drawing.Point(24, 211);
            this.stateLbl.Name = "stateLbl";
            this.stateLbl.Size = new System.Drawing.Size(72, 29);
            this.stateLbl.TabIndex = 8;
            this.stateLbl.Text = "State:";
            // 
            // zipCodetxtBx
            // 
            this.zipCodetxtBx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.zipCodetxtBx.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zipCodetxtBx.Location = new System.Drawing.Point(186, 252);
            this.zipCodetxtBx.Name = "zipCodetxtBx";
            this.zipCodetxtBx.Size = new System.Drawing.Size(127, 32);
            this.zipCodetxtBx.TabIndex = 9;
            // 
            // stateComboBx
            // 
            this.stateComboBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.stateComboBx.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stateComboBx.FormattingEnabled = true;
            this.stateComboBx.Items.AddRange(new object[] {
            "KY",
            "GA",
            "CA",
            "NY"});
            this.stateComboBx.Location = new System.Drawing.Point(186, 208);
            this.stateComboBx.Name = "stateComboBx";
            this.stateComboBx.Size = new System.Drawing.Size(121, 37);
            this.stateComboBx.TabIndex = 10;
            // 
            // submitBtn
            // 
            this.submitBtn.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submitBtn.Location = new System.Drawing.Point(29, 318);
            this.submitBtn.Name = "submitBtn";
            this.submitBtn.Size = new System.Drawing.Size(163, 78);
            this.submitBtn.TabIndex = 11;
            this.submitBtn.Text = "Submit Form";
            this.submitBtn.UseVisualStyleBackColor = true;
            this.submitBtn.Click += new System.EventHandler(this.submitBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelBtn.Location = new System.Drawing.Point(277, 318);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(161, 78);
            this.cancelBtn.TabIndex = 12;
            this.cancelBtn.Text = "Cancel Form";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // AddressForm
            // 
            this.AcceptButton = this.submitBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.submitBtn);
            this.Controls.Add(this.stateComboBx);
            this.Controls.Add(this.zipCodetxtBx);
            this.Controls.Add(this.stateLbl);
            this.Controls.Add(this.zipLbl);
            this.Controls.Add(this.CitytxtBx);
            this.Controls.Add(this.Addtxt2Bx);
            this.Controls.Add(this.cityLbl);
            this.Controls.Add(this.addTxt1Bx);
            this.Controls.Add(this.addressLbl);
            this.Controls.Add(this.nameTxtBx);
            this.Controls.Add(this.nameLbl);
            this.Name = "AddressForm";
            this.Text = "AddressForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label addressLbl;
        private System.Windows.Forms.Label cityLbl;
        private System.Windows.Forms.Label zipLbl;
        private System.Windows.Forms.Label stateLbl;
        private System.Windows.Forms.Button submitBtn;
        private System.Windows.Forms.Button cancelBtn;
        protected internal System.Windows.Forms.TextBox nameTxtBx;
        protected internal System.Windows.Forms.TextBox addTxt1Bx;
        protected internal System.Windows.Forms.TextBox Addtxt2Bx;
        protected internal System.Windows.Forms.TextBox CitytxtBx;
        protected internal System.Windows.Forms.ComboBox stateComboBx;
        protected internal System.Windows.Forms.TextBox zipCodetxtBx;
    }
}