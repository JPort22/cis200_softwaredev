﻿//Grading ID: M1402
//Program 2: AddressForm.cs for Address Form where user inputs new address for storage.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    //AddressForm coming from the Program 2 form when choosing the Address tab 
    public partial class AddressForm : Form
    {
        int zip;//zip variable
        const int ZIP_LOW = 00000;//lowest value for zip
        const int ZIP_HI = 99999;//highest value for zip
        public AddressForm()
        {
            InitializeComponent();
        }
        //Precondition: submit button is clicked
        //Postcondition: verifies items for validation after click then outputs to bigTxBx display
        private void submitBtn_Click(object sender, EventArgs e)
        {

            string errorAddResult = string.Empty;//error message result for address form
            
            if (string.IsNullOrEmpty(nameTxtBx.Text))//validation for name input
            {
                errorAddResult += "Please enter Name!" + Environment.NewLine;
            }
            
            if (string.IsNullOrEmpty(addTxt1Bx.Text))//validation for address 1 input
            {
                errorAddResult += "Please enter Address Line 1!" + Environment.NewLine;
            }
            
            if (string.IsNullOrEmpty(CitytxtBx.Text))//validation for city input
            {
               errorAddResult += "Please enter City!" + Environment.NewLine;
            }

            if (stateComboBx.SelectedItem == null)//validation for state combo box selection/input
            {
                errorAddResult += "Please select State in given list!" + Environment.NewLine;
            }
            

            if (int.TryParse(zipCodetxtBx.Text, out zip))//validation for zip input
            {
                if(zip < ZIP_LOW || zip > ZIP_HI)//makes sure zip is within range
                {
                    errorAddResult += "Please enter valid Zip Code between 00000 and 99999!" + Environment.NewLine;
                }
            }
            else//makes sure zip is numeric value
            {
                errorAddResult += "Please enter numeric values for Zip Code!" + Environment.NewLine;
            }

            if(errorAddResult == string.Empty)//shows nothing if all input is ok
            {
                this.DialogResult = DialogResult.OK;
            }
            else//otherwise shows messagebox with all error results
            {
                MessageBox.Show(errorAddResult);
            }

            
        }
        //Precondition: cancel form button is clicked on address form
        //Postcodition: cancels form and returns to main form
        private void cancelBtn_Click(object sender, EventArgs e)//event that happens when cancel button is clicked
        {
            DialogResult cancel = new DialogResult();
            cancel = MessageBox.Show("Are you sure you want to cancel?", "Cancel??", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
            if(cancel == DialogResult.Yes)
            {
                this.Close();
            }
        }

        
    }
}
