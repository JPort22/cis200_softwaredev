﻿namespace UPVApp
{
    partial class LetterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LetterForm));
            this.originAddLbl = new System.Windows.Forms.Label();
            this.destAddLbl = new System.Windows.Forms.Label();
            this.fixedCostLbl = new System.Windows.Forms.Label();
            this.originAddCbBx = new System.Windows.Forms.ComboBox();
            this.destAddCbBx = new System.Windows.Forms.ComboBox();
            this.fixedCostTxBx = new System.Windows.Forms.TextBox();
            this.letterSubmitBtn = new System.Windows.Forms.Button();
            this.letterCancelBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // originAddLbl
            // 
            this.originAddLbl.AutoSize = true;
            this.originAddLbl.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originAddLbl.Location = new System.Drawing.Point(32, 34);
            this.originAddLbl.Name = "originAddLbl";
            this.originAddLbl.Size = new System.Drawing.Size(178, 29);
            this.originAddLbl.TabIndex = 0;
            this.originAddLbl.Text = "Origin Address: ";
            // 
            // destAddLbl
            // 
            this.destAddLbl.AutoSize = true;
            this.destAddLbl.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.destAddLbl.Location = new System.Drawing.Point(32, 78);
            this.destAddLbl.Name = "destAddLbl";
            this.destAddLbl.Size = new System.Drawing.Size(224, 29);
            this.destAddLbl.TabIndex = 1;
            this.destAddLbl.Text = "Destination Address:";
            // 
            // fixedCostLbl
            // 
            this.fixedCostLbl.AutoSize = true;
            this.fixedCostLbl.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fixedCostLbl.Location = new System.Drawing.Point(32, 144);
            this.fixedCostLbl.Name = "fixedCostLbl";
            this.fixedCostLbl.Size = new System.Drawing.Size(125, 29);
            this.fixedCostLbl.TabIndex = 2;
            this.fixedCostLbl.Text = "Fixed Cost:";
            // 
            // originAddCbBx
            // 
            this.originAddCbBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.originAddCbBx.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originAddCbBx.FormattingEnabled = true;
            this.originAddCbBx.Location = new System.Drawing.Point(238, 34);
            this.originAddCbBx.Name = "originAddCbBx";
            this.originAddCbBx.Size = new System.Drawing.Size(416, 37);
            this.originAddCbBx.TabIndex = 3;
            // 
            // destAddCbBx
            // 
            this.destAddCbBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.destAddCbBx.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.destAddCbBx.FormattingEnabled = true;
            this.destAddCbBx.Location = new System.Drawing.Point(284, 85);
            this.destAddCbBx.Name = "destAddCbBx";
            this.destAddCbBx.Size = new System.Drawing.Size(370, 37);
            this.destAddCbBx.TabIndex = 4;
            // 
            // fixedCostTxBx
            // 
            this.fixedCostTxBx.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fixedCostTxBx.Location = new System.Drawing.Point(163, 141);
            this.fixedCostTxBx.Name = "fixedCostTxBx";
            this.fixedCostTxBx.Size = new System.Drawing.Size(127, 32);
            this.fixedCostTxBx.TabIndex = 5;
            // 
            // letterSubmitBtn
            // 
            this.letterSubmitBtn.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.letterSubmitBtn.Location = new System.Drawing.Point(58, 250);
            this.letterSubmitBtn.Name = "letterSubmitBtn";
            this.letterSubmitBtn.Size = new System.Drawing.Size(152, 80);
            this.letterSubmitBtn.TabIndex = 6;
            this.letterSubmitBtn.Text = "Submit Form";
            this.letterSubmitBtn.UseVisualStyleBackColor = true;
            this.letterSubmitBtn.Click += new System.EventHandler(this.letterSubmitBtn_Click);
            // 
            // letterCancelBtn
            // 
            this.letterCancelBtn.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.letterCancelBtn.Location = new System.Drawing.Point(347, 250);
            this.letterCancelBtn.Name = "letterCancelBtn";
            this.letterCancelBtn.Size = new System.Drawing.Size(158, 80);
            this.letterCancelBtn.TabIndex = 7;
            this.letterCancelBtn.Text = "Cancel Form";
            this.letterCancelBtn.UseVisualStyleBackColor = true;
            this.letterCancelBtn.Click += new System.EventHandler(this.letterCancelBtn_Click);
            // 
            // LetterForm
            // 
            this.AcceptButton = this.letterSubmitBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.letterCancelBtn);
            this.Controls.Add(this.letterSubmitBtn);
            this.Controls.Add(this.fixedCostTxBx);
            this.Controls.Add(this.destAddCbBx);
            this.Controls.Add(this.originAddCbBx);
            this.Controls.Add(this.fixedCostLbl);
            this.Controls.Add(this.destAddLbl);
            this.Controls.Add(this.originAddLbl);
            this.Name = "LetterForm";
            this.Text = "LetterForm";
            this.Load += new System.EventHandler(this.LetterForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label originAddLbl;
        private System.Windows.Forms.Label destAddLbl;
        private System.Windows.Forms.Label fixedCostLbl;
        private System.Windows.Forms.Button letterSubmitBtn;
        private System.Windows.Forms.Button letterCancelBtn;
        protected internal System.Windows.Forms.ComboBox originAddCbBx;
        protected internal System.Windows.Forms.ComboBox destAddCbBx;
        protected internal System.Windows.Forms.TextBox fixedCostTxBx;
    }
}