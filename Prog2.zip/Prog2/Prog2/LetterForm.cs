﻿//Grading ID: M1402
//Letter form info from user input
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class LetterForm : Form
    {
        private List<Address> addyList;

        decimal fixedCost;//fixed cost variable as decimal
        const int ZERO_DUH = 0;//const int for a value of 0

        //Precondition: Needs the list of Address objects
        //Postcondition: Letter form is running and address list items are put as backing fields
        public LetterForm(List<Address> ad)
        {
            InitializeComponent();
            
            addyList = ad;
        }
         
        internal Address OriginAddress
        {
            //Precondition: none
            //Postcondition: choice in origin address combo box is returned as Address
            get
            {
                int choice;//choice as int for index position
                choice = originAddCbBx.SelectedIndex;
                return addyList[choice];
            }
        }
        
        internal Address DestinationAddress
        {
            //Precondition: none
            //Postcondition: choice in destination combo box is returned as Address
            get
            {
                int choice;//choice as int for index position
                choice = destAddCbBx.SelectedIndex;
                return addyList[choice];
           }
        }
        //Precondition: submit button is clicked on letter form
        //Postcondition: if choice is valid then it will go through if not errorLetterResult will pop up
        private void letterSubmitBtn_Click(object sender, EventArgs e)
        {
            string errorLetterResult = string.Empty;

            if (originAddCbBx.SelectedItem == null)//if no choice is selected
            {
                errorLetterResult += "Please select Origin Address in given list!" + Environment.NewLine;
            }

            if (destAddCbBx.SelectedItem == null)//if no choice is selected 
            {
                errorLetterResult += "Please select Letter Address in given list!" + Environment.NewLine;
            }

            if (originAddCbBx.SelectedItem == destAddCbBx.SelectedItem)//if selections match
            {
                errorLetterResult += "Please do not use matching addresses!" + Environment.NewLine;
            }

            if(decimal.TryParse(fixedCostTxBx.Text, out fixedCost))//validation for fixed cost
            {
                if(fixedCost < ZERO_DUH)
                {
                    errorLetterResult += "Please enter valid Fixed Cost!" + Environment.NewLine;
                }

            }
            else//if fixed cost is no numeric 
            {
                errorLetterResult += "Please enter numeric values for Fixed Cost!" + Environment.NewLine;
            }


            if (errorLetterResult == string.Empty)
            {
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show(errorLetterResult);
            }


        }
        //Precondition: cancel from button is clicked
        //Postcondition: cancels form and returns user to original form
        private void letterCancelBtn_Click(object sender, EventArgs e)
        {
            DialogResult cancel = new DialogResult();
            cancel = MessageBox.Show("Are you sure you want to cancel?", "Cancel??", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
            if (cancel == DialogResult.Yes)
            {
                this.Close();
            }
        }
        //Precondition: None
        //Postcondition: Origin Address and Destination Address combo box are populated with name values
        private void LetterForm_Load(object sender, EventArgs e)
        {
            foreach(Address a in addyList)
            {
                originAddCbBx.Items.Add(a.Name);
                destAddCbBx.Items.Add(a.Name);
            }
        }
    }
}
