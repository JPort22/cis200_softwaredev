﻿//Grading ID: M1402
//Program 2 form with menu tabs and menu items to select from
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class Prog2Form : Form
    {
        UserParcelView upv = new UserParcelView();//makes an object of the UPV class
        
        //Precondition: None
        //Postcondition: GUI is running, and all of the diff. objects are added to the form
        public Prog2Form()
        {
            InitializeComponent();
            upv.AddAddress("Mary Jane", "420 THC Avenue", "Tegridy Farms", "CA", 42069);//adds to address list 
            upv.AddAddress("Patrick Star", "23 Under Rock Ct.", "Bikini Bottom", "GA", 55631);//adds to address list
            upv.AddAddress("Kacchan Bakugo", "557 Explosive Made Rd.", "Apt.13", "Sunjuku", "KY", 73342);//adds to address list
            upv.AddAddress("Chester Cheeto", "1165 Flamin Hot Ct.", "Puff Puff", "NY", 00674);//adds to address list
            upv.AddAddress("Wonder Woman", "389 Goddess Blvd.", "Themyscira", "CA", 78554);//adds to address list
            upv.AddAddress("Light Yagami", "666 Your Name Rd.", "Death Note", "KY", 43329);//adds to address list

            upv.AddLetter(upv.addresses[0], upv.addresses[5], 2.74M);//adds to parcel list as letter
            upv.AddLetter(upv.addresses[3], upv.addresses[4], 1.63M);//adds to parcel list as letter

            upv.AddGroundPackage(upv.addresses[2], upv.addresses[1], 11.3, 7.4, 10.6, 23.5);//adds to parcel list as ground package
            upv.AddGroundPackage(upv.addresses[5], upv.addresses[3], 21.4, 5.8, 13.9, 16.7);//adds to parcel list as ground package

            upv.AddNextDayAirPackage(upv.addresses[1], upv.addresses[4], 5.9, 10.1, 7.3, 16.4, 4.76M);//adds to parcel list as a next day air package
            upv.AddNextDayAirPackage(upv.addresses[0], upv.addresses[2], 16.5, 14.9, 23.2, 34.7, 16.8M);//adds to parcel list as a next day air package

            upv.AddTwoDayAirPackage(upv.addresses[3], upv.addresses[0], 23.8, 39.1, 14.5, 28.5, TwoDayAirPackage.Delivery.Saver);//adds to parcel list as a two day air package
            upv.AddTwoDayAirPackage(upv.addresses[4], upv.addresses[5], 17.6, 11.9, 20.7, 56.4, TwoDayAirPackage.Delivery.Early);//adds to parcel list as a two day air package
        }
        //Precondition: The about menu item is clicked
        //Postcondition: A message box comes up with info
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Grading ID: M1402 | CIS 200-01 | Due Date: 10/21/2019 | Program 2");
        }
        //Precondition: The exit menu item is clicked
        //Postcondition: User exits out of the Program 2 form
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //Precondition: The address menu item is clicked
        //Postcondition: A dialog box pops up ready for user input to create another address item for further action
        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddressForm addressform = new AddressForm();//makes dialog box come up when clicking address menu item
            DialogResult result; //builds result for dialog box
            string name;//name variable as string
            string addy1;//address 1 variable as string
            string addy2;//address 2 variable as string
            string state;//state variable as string
            string city;//city variable as string
            int zipCode;//zip code variable as string

            result = addressform.ShowDialog();
            //if submit is clicked then this if statement checks out the properties
            if(result == DialogResult.OK)
            {
                name = addressform.nameTxtBx.Text;
                addy1 = addressform.addTxt1Bx.Text;
                addy2 = addressform.Addtxt2Bx.Text;
                city = addressform.CitytxtBx.Text;
                state = addressform.stateComboBx.Text;
                zipCode = int.Parse(addressform.zipCodetxtBx.Text);

                upv.AddAddress(name, addy1, addy2, city, state, zipCode);
            }
            
        }
        //Precondition: The letter menu item is clicked 
        //Postcondition: Dialog box pops up for a user to enter letter information, then adds to list after verification
        private void listAddressesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bigResultTxBx.Text = string.Empty;

            foreach (Address ad in upv.addresses)
                bigResultTxBx.Text += ad + Environment.NewLine + Environment.NewLine;
        }

        private void letterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LetterForm letterform = new LetterForm(upv.AddressList);//dialog box pops up ready for user input
            DialogResult resultO;//result for dialog input
            Address orgAddress;//origin address
            Address destAddress;//destination address
            decimal fixedCost;//fixed cost variable as decimal

            resultO = letterform.ShowDialog();
            //verifies when sumbit button is clicked and creates the letter object with info
            if(resultO == DialogResult.OK)
            {
                orgAddress = letterform.OriginAddress;
                destAddress = letterform.DestinationAddress;
                fixedCost = decimal.Parse(letterform.fixedCostTxBx.Text);

                upv.AddLetter(orgAddress, destAddress, fixedCost);
            }

            
        }
        //Precondition: list parcel menu item is clicked
        //Postcondition: bigTxtBx displays list of parcels after being cleared 
        private void listParcelsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bigResultTxBx.Text = string.Empty;//big text box for result display
            string totalCostDis = string.Empty;//display for total shipping cost
            decimal shipTotal = 0M;//decimal variable for shipping total

            //this foreach loop displays each parcels within the upv and solves total cost
            foreach(Parcel pc in upv.parcels)
            {
                bigResultTxBx.Text += pc + Environment.NewLine + Environment.NewLine;
                shipTotal += pc.CalcCost();
            }

            totalCostDis = $"Total Cost: {shipTotal:C}";//displays total cost
            bigResultTxBx.Text += totalCostDis;//adds total cost display to bigTxBx result

        }
    }
}
