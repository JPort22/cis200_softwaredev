﻿//Grading ID: M1402
//Program 3: Edit address, not making another object just changing attributes of a previously made address
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    //This is the Edit Address form where the user is prompted to select an address from a given list
    //once selected, the necessary elements for the choosen address is populated from the data
    public partial class EditAddressForm : Form
    {

        public const int MIN_ADDRESSES = 1; // Minimum number of addresses needed
        private List<Address> addressList;  // List of addresses used to fill combo boxes
        internal Address editAddress;//variable that references address to edit
        //Precondition: addresses.Count >= MIN_ADDRESSES
        //Postcondition: The form's GUI is prepared for display.
        public EditAddressForm(List<Address> addresses)
        {
            InitializeComponent();
            addressList = addresses;
        }
        
        internal int AddressComboBox
        {
            //Precondition:  User has selected from address combo box
            // Postcondition: The index of the selected address returned
            get
            {
                return addressCmbBx.SelectedIndex;
            }
            // Precondition:  -1 <= value < addressList.Count
            // Postcondition: The specified index is selected in address combo box

            set
            {
                if ((value >= -1) && (value < addressList.Count))
                    addressCmbBx.SelectedIndex = value;
                else
                    throw new ArgumentOutOfRangeException("AddressComboBox", value,
                        "Index must be valid");
            }
        }
        // Precondition:  Submit button is clicked
        // Postcondition: If wrong input, dialog asks for right input input, then if ok the form 
        // form closes
        private void submitBtn_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
            {
                DialogResult result;
                AddressForm addressForm = new AddressForm();
                editAddress = addressList[AddressComboBox];

                addressForm.AddressName = editAddress.Name;
                addressForm.Address1 = editAddress.Address1;
                addressForm.Address2 = editAddress.Address2;
                addressForm.City = editAddress.City;
                addressForm.State = editAddress.State;
                addressForm.ZipText = editAddress.Zip.ToString();

                result = addressForm.ShowDialog();

                if(result == DialogResult.OK)
                {
                    editAddress.Name = addressForm.AddressName;
                    editAddress.Address1 = addressForm.Address1;
                    editAddress.Address2 = addressForm.Address2;
                    editAddress.City = addressForm.City;
                    editAddress.State = addressForm.State;
                    editAddress.Zip = int.Parse(addressForm.ZipText);
                }
                this.DialogResult = DialogResult.OK;
            }
            
                
        }
        //Precondition:  addressList.Count >= MIN_ADDRESSES
        // Postcondition: The list of addresses is used to populate the
        //                 address combo box
        private void EditAddressForm_Load(object sender, EventArgs e)
        {
            if (addressList.Count < MIN_ADDRESSES) // precondition is not permitted
            {
                MessageBox.Show("Need " + MIN_ADDRESSES + " address selected for editing!",
                    "Address Error");
                this.DialogResult = DialogResult.Abort; // Gets rid of it
            }
            else
            {
                foreach (Address a in addressList)
                {
                    addressCmbBx.Items.Add(a.Name);
                    
                }
            }
        }
        //Precondition:  focus moves from addresses in combo box
        // Postcondition: If no address selected, error provider comes up
        private void addressCmbBx_Validating(object sender, CancelEventArgs e)
        {
            ComboBox cbo = sender as ComboBox; // Cast sender as combo box

            if (cbo.SelectedIndex == -1) // -1 equals no selection
            {
                e.Cancel = true;
                addSelectEP.SetError(cbo, "Must select an address");
            }
        }
        //Precondition:  data is ok to transfer since passing requirement
        // Postcondition: Error provider goes away 
        private void addressCmbBx_Validated(object sender, EventArgs e)
        {
            Control control = sender as Control; // Cast sender as Control
                                                 
            addSelectEP.SetError(control, "");
        }
        //// Precondition:  Cancel button is pressed
        // Postcondition: form closes out
        private void cancelBtn_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // Was it a left-click?
                this.DialogResult = DialogResult.Cancel;
        }
    }
}
