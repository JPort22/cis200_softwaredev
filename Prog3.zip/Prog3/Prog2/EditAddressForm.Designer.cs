﻿namespace UPVApp
{
    partial class EditAddressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.chooseAddLbl = new System.Windows.Forms.Label();
            this.submitBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.addressCmbBx = new System.Windows.Forms.ComboBox();
            this.addSelectEP = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.addSelectEP)).BeginInit();
            this.SuspendLayout();
            // 
            // chooseAddLbl
            // 
            this.chooseAddLbl.AutoSize = true;
            this.chooseAddLbl.Location = new System.Drawing.Point(28, 22);
            this.chooseAddLbl.Name = "chooseAddLbl";
            this.chooseAddLbl.Size = new System.Drawing.Size(155, 20);
            this.chooseAddLbl.TabIndex = 0;
            this.chooseAddLbl.Text = "Choose An Address:";
            // 
            // submitBtn
            // 
            this.submitBtn.Location = new System.Drawing.Point(32, 130);
            this.submitBtn.Name = "submitBtn";
            this.submitBtn.Size = new System.Drawing.Size(99, 48);
            this.submitBtn.TabIndex = 1;
            this.submitBtn.Text = "Submit";
            this.submitBtn.UseVisualStyleBackColor = true;
            this.submitBtn.Click += new System.EventHandler(this.submitBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(334, 130);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(93, 48);
            this.cancelBtn.TabIndex = 2;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cancelBtn_MouseDown);
            // 
            // addressCmbBx
            // 
            this.addressCmbBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addressCmbBx.FormattingEnabled = true;
            this.addressCmbBx.Location = new System.Drawing.Point(200, 22);
            this.addressCmbBx.Name = "addressCmbBx";
            this.addressCmbBx.Size = new System.Drawing.Size(227, 28);
            this.addressCmbBx.TabIndex = 3;
            this.addressCmbBx.Validating += new System.ComponentModel.CancelEventHandler(this.addressCmbBx_Validating);
            this.addressCmbBx.Validated += new System.EventHandler(this.addressCmbBx_Validated);
            // 
            // addSelectEP
            // 
            this.addSelectEP.ContainerControl = this;
            // 
            // EditAddressForm
            // 
            this.AcceptButton = this.submitBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(843, 247);
            this.Controls.Add(this.addressCmbBx);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.submitBtn);
            this.Controls.Add(this.chooseAddLbl);
            this.Name = "EditAddressForm";
            this.Text = "EditAddressForm";
            this.Load += new System.EventHandler(this.EditAddressForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.addSelectEP)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label chooseAddLbl;
        private System.Windows.Forms.Button submitBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.ComboBox addressCmbBx;
        private System.Windows.Forms.ErrorProvider addSelectEP;
    }
}