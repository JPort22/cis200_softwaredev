﻿//Grading ID: M1402
//CIS 200-01
//Due Date:09/09/2019
//This is where we create the parcel objects and create the values for the properties made
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    public class ParcelTest //parcel test class where objects are created and values specified
    {
        //Precondition: None
        //Postcondition: tests the multiple address objects called addy() in the body
        static void Main(string[] args)
        {

            Address addy1 = new Address("The Dark Knight", "The BatCave", "2839 Wayne Manor", "Gotham", "New Jersey", 07097);//address one for letters
            Address addy2 = new Address("Winnie Pooh", "100 Acre Woods", "East Sussex", "England", 0);//address two for letters
            Address addy3 = new Address("Naruto Uzumaki", "242 Ichiraku Apt. 9", "The Leaf Village", "Land of Fire", 00009);//address three for letters
            Address addy4 = new Address("Kirby", " 4605 DreamLand", "DreamCity", "Colorado", 37125);//address four for letters

            Letter letter1 = new Letter(addy2, addy4, 13);//letter one with address two being origin and address four being destination along with fixed cost
            Letter letter2 = new Letter(addy3, addy1, 6.75m);//letter two with address three being origin and address one being destination along with fixed cost
            Letter letter3 = new Letter(addy1, addy4, 24);//letter three with address one being the origin and address three being the destination alon with fixed cost

            List<Letter> letters = new List<Letter>();//displays letter objects in order intended
            letters.Add(letter1);
            letters.Add(letter2);
            letters.Add(letter3);

            foreach (Letter letter in letters)//foreach loop that displays the output of the Letter list by stepping through each one
            {
                Console.WriteLine($"{Environment.NewLine}*Letter*{Environment.NewLine} {letter.ToString()}");
            }
                
        }
        
    }
}
