﻿//Grading ID: M1402
//CIS 200-01
//Due Date: 09/09/2019
//This is the letter class that is derived from the parcel class and obtains methods for the objects
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    public class Letter : Parcel
    {
        private decimal _fixedCost;//backing field for fixed cost for the parcel
        public const int ZERO = 0;//the constant of zero for the amount
        //Precondition: Origin and Destination address taken from parcel class and validates Fixed Cost
        //Postcondition: Letters are created with their origin, destination address, and the fixed cost as well
        public Letter(Address originAddress, Address destinationAddress, decimal fixedCost) :base(originAddress, destinationAddress)
        {
            FixedCost = fixedCost;
        }

        protected decimal FixedCost//Fixed cost property
        {
            //Precondition: None
            //Postcondition: returns fixed cost
            get
            {
                return _fixedCost;
            }
            //Precondition: the value is expected to be greater than zero if not then the program is thrown
            //Postcondition: setting the fixed cost value to the specified value
            set
            {
                if(value < ZERO)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(FixedCost)} must be a positive value.");
                }
                _fixedCost = value;
            }
        }
        //Precondition: None
        //Postcondition: Displays and calculates the fixed cost
        public override decimal CalcCost()
        {
            
            decimal resultNum;//results variable for the fixed cost property
            resultNum = FixedCost;
            return resultNum;
        }
        //Precondition: None
        //Postcondition: string is returned with letter details
        public override string ToString()
        {
            string resultTwo;//result string variable for the fixed cost
            resultTwo = base.ToString() + $" Fixed Cost: {FixedCost:C}";
            return resultTwo;
        }



    }
}
