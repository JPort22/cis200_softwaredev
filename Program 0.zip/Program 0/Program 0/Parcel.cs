﻿//Grading ID:M1402
//CIS 200-01
//Due Date:09/09/2019
//Program 0
//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    public abstract class Parcel
    {
        private Address _originAddress;//backing fields for origin address
        private Address _destinationAddress;//backing fields for destination address
        //Precondition: Handles the display for the address
        //Postcondition: Parcel is made with an origin and destination address
        public Parcel (Address orgAdd, Address destAdd)//parcel constructor
        {
            OriginAddress = orgAdd;
            DestinationAddress = destAdd;
        }

        public Address OriginAddress
        {
            //Precondition: None
            //Postcondition: returns origin Address
            get
            {
                return _originAddress;
            }
            //Precondition: None
            //Postcondition: setting origin Address to specified value
            set
            {
                _originAddress = value;
            }
        }
        
        public Address DestinationAddress
        {
            //Precondition: None
            //Postcondition: returns destination address
            get
            {
                return _destinationAddress;
            }
            //Precondition: 
            //Postcondition: setting the destination address to specified value
            set
            {
                _destinationAddress = value;
            }
        }
        //Precondition: None
        //Postcondition: calculates the cost
        public abstract decimal CalcCost();
        //Precondition: None
        //Postcondition: string is returned with letter details
        public override string ToString()
        {
            string resultOne;//result variable string that displays the origin and destination address from the objects in Parcel and the properties in the Address class
            resultOne = $"Origin Address: {Environment.NewLine} {OriginAddress}{Environment.NewLine}" +
                $"Destination Address:{Environment.NewLine} {DestinationAddress}{Environment.NewLine}";
            return resultOne;
        }
        
    }
}
