﻿//Grading ID:M1402
//CIS 200-01
//Due Date:09/09/2019
//Address class where we build the basis for the letter info with backing fields and validation sets
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    public class Address//Address class where it holds the backing fields for validation
    {
        private string _name;//backing field for name
        private string _address1;//backing field for address 1
        private string _address2;//backing field for address 2
        private string _city;//backing field for city
        private string _state;//backing field for state
        private int _zipCode;//backing field for zip code
        const int ZIP_LO = 00000;//lowest zip code available
        const int ZIP_HI = 99999;//highest zip code available
        
        //Precondition: parameters need to be met by objects created in ParcelTest
        //Postcondtion: a parcel's destination and origin address is created like a packaging label object

        public Address(string name, string address1, string address2, string city, string state, int zipCode)//Address constructor that instantiates variables for validation to make properties
        {    
            Name = name;
            Address1 = address1;
            Address2 = address2;
            City = city;
            State = state;
            Zip = zipCode;
        }

        //Precondition: parameters need to be met, this time without address2 present in the backing field properties
        //Postcondition: a parcel's destination and origin address is created by overloaded if not containing a second line for address 2

        public Address(string name, string address1, string city, string state, int zipCode)
        {
            Name = name;
            Address1 = address1;
            Address2 = string.Empty;
            City = city;
            State = state;
            Zip = zipCode;
        }

        public string Name//name property
        {
            //Precondition: None
            //Postcondition: returns name
            get
            {
                return _name;
            }
            //Precondition: value of the name is set to be trimmed and if not any value present program is thrown
            //Postcondition: setting the name of property to the specified value 
            set
            {
                _name = value.Trim();

                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(Name)} must not be blank.");
                }
                _name = value;
            }
        }
        public string Address1//address1 property
        {
            //Precondition: None
            //Postcondition: returns address 1
            get
            {
                return _address1;
            }
            //Precondition: value of the address 1 is set to be trimmed and if not any value present then the program is thrown
            //Postcondition: setting the address 1 to the specified value 
            set
            {
                _address1 = value.Trim();

                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(Address1)} must not be blank.");
                }
                _address1 = value;
            }
        }
        public string Address2//address 2 property
        {
            //Precondition: None
            //Postcondition: returns address 2 
            get
            {
                return _address2;
            }
            //Precondition: value of the address 2 property is set to be trimmed
            //Postcondition: setting the address 2 property to the specified value

            set
            {
                _address2 = value.Trim();
                
                _address2 = value;
                
            }

        }
        public string City//city property
        {
            //Precondition: None
            //Postcondition: returns city property
            get
            {
                return _city;
            }
            //Precondition: value of the city property is set to be trimmed and then if no value present then the program is thrown
            //Postcondition: setting the city to the specified value
            set
            {
                _city = value.Trim();

                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(City)} must not be blank.");
                }
                _city = value;
            }
        }
        public string State//state property
        {
            //Precondition: None
            //Postcondition: returns state 
            get
            {
                return _state;
            }
            //Precondition: value of state is set to be trimmed and if no value is present then the program is thrown
            //Postcondition: setting the state to the specified value
            set
            {
                _state = value.Trim();

                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(State)} must not be blank.");
                }
                _state = value;
            }
        }
        public int Zip//zip code property
        {
            //Precondition: None
            //Postcondition: returns zip property
            get
            {
                return _zipCode;
            }
            //Precondition: value of the zip code is set to be trimmed and then if no value present the program is thrown
            //Postcondition: setting the zip code 
            set
            {
               if (value < ZIP_LO || value > ZIP_HI)
               {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(Zip)} must be between 00000 and 99999.");
               }
                _zipCode = value;

            }
        }
        //Output Results
        public override string ToString()
        {
            string result;//result for address-origin or destination
            result = $" Name: {Name}{Environment.NewLine}" + $" Address Line 1: {Address1}{Environment.NewLine}";
            if (!String.IsNullOrEmpty(Address2))
                result += $" Address Line 2: {Address2}{Environment.NewLine}";  
                   result += $"{City}"+
                $" , {State}" + $" {Zip:D5}{Environment.NewLine}";
            return result;
        }
    }
}
